# Abdalrhman Mohmed — Portfolio

Personal portfolio built with plain HTML, CSS and JavaScript (no build step).

Live: https://abdalrhmanmohmedfarouk.github.io
